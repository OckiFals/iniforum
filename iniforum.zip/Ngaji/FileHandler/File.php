<?php namespace Ngaji\FileHandler;

class File {
	public static function upload($type='img', $name) {

    }
}

