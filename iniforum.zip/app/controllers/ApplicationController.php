<?php namespace app\contollers;

/**
 * ApplicationController
 *
 * Is a basic contoller for the app.
 * This perform basic actions that can be performed by all users
 * like access the index and login page.
 *
 * @package app/controllers
 * @author  Ocki Bagus Pratama
 * @date    14/02/15
 * @time    14:09
 * @since   1.0.0
 */

use app\models\Posts;
use Ngaji\Http\Request;
use Ngaji\Http\Response;
use Ngaji\Http\Session;
use Ngaji\Routing\Controller;
use Ngaji\view\View;

use app\models\Accounts;

# use Response::render() func. to include template without passing array data
class ApplicationController extends Controller {

    public static function index() {
        # if user was login before and session is still valid
        if (Request::is_authenticated()) {
            if (Request::is_admin()) {
                AdminController::index();
            } else {
                MemberController::index();
            }
        } else {
            $posts = Posts::all();
            $categories = array(
                0 => [
                    'name' => 'Politic'
                ]
            );

            # /app/views/waitress/order.php
            View::render('home', [
                'posts' => $posts,
                'categories' => $categories
            ]);
        }
    }

    public static function profile() {
        # self::login_required();

        # get id account from request header
        $id = Request::user()->id;
        # fetch user data account
        $account = Accounts::findByPK($id);

        print_r($account);

        Response::render('hello profile');
    }

    public static function login() {
        if (Request::is_authenticated()) 
            Response::redirect('index.php');
        
        if ("POST" == Request::method()) {
            $username = Request::POST()->username;
            $password = Request::POST()->password;

            $auth = self::auth($username, $password);

            if ($auth) {
                Response::redirect('index.php');
            } else {
                View::render('login', [
                    'message' => 'login_failure'
                ]);
            }
        } else {
            View::render('login');
        }
    }

    public static function logout() {
        $session = new Session();

        if ($session->has('id_account'))
            $session->delete('id_account');

        $session->destroy();

        Response::redirect('index.php');
    }
}
