<?php namespace app\contollers;

use app\models\Accounts;
use app\models\Posts;
use Ngaji\Http\Request;
use Ngaji\Routing\Controller;
use Ngaji\view\View;

# use Response::render() func. to include template without passing array data
class MemberController extends Controller {

    public static function index() {

        $posts = Posts::all();

        # /app/views/waitress/order.php
        View::render('home', [
            'posts' => $posts
        ]);
    }

    /**
     * Render the profile page
     *
     */
    public static function profile() {
        # get id account from request header
        $id = Request::user()->id;
        # fetch user data account
        $account = Accounts::findByPK($id);
        print_r($account);
    }

    /**
     * Add member post
     *
     */
    public static function addPost() {
        self::login_required();

        $id_member = Request::user()->id;
        $data = Request::POST()->post;

        $post = new Posts();
        $post->id = $id_member;
        $post->post = $data;
        # $post->save();

        print_r($post);

        echo $post->post;

        # Posts::create($id_member, $data);

        # Response::render($data . $id_member);
    }

}
