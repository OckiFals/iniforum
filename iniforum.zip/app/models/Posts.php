<?php namespace app\models;

use Ngaji\Database\ActiveRecord;

class Posts extends ActiveRecord {

    public function __construct($dataModel = [], $className=__CLASS__) {
        class_parents($className);
        parent::__construct($dataModel);
    }

    public function tableName() {
        return 'posts';
    }

    public function attributes() {
        return array(
            # `id`, `id_account`, `post`, `created_at`, `modified_at`
            'id' => [
                'integer',
                'auto_increment'
            ],
            'id_account' => 'integer',
            'post' => 'text',
            'created_at' => 'time',
            'modified_at' => 'time'
        );
    }

    public function rules() {
        return array(
            'primary_key' => 'id',
            'many_to_one' => [
                'accounts' => 'id'
            ]
        );
    }

    public static function create($id, $post) {

        $cleanPost = \Post::sensor($post);

        $sql = sprintf("INSERT INTO `iniforum`.`posts` (
            `id`, `id_account`, `post`, `created_at`, `modified_at`
            ) VALUES (NULL, :id, :post, now(), CURRENT_TIMESTAMP)"
        );

        $bindArray = [
            ':id' => $id,
            ':post' => $cleanPost,
        ];

        self::query($sql, $bindArray);
    } 

    public function delete($value='') {
        # code...
    }
}