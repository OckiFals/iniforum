<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>News Feeds</title>
    <?= Ngaji\view\View::makeHead() ?>
    <?php
    /**
     * @var array $categories
     * @var array $posts
     */
    ?>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
<body class="skin-blue layout-top-nav">
<div class="wrapper">

    <header class="main-header">
        <?= Ngaji\view\View::makeHeader() ?>
    </header>
    <!-- Full Width Column -->
    <div class="content-wrapper">
        <div class="container">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Web System
                    <small> 1.0</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </section>

            <div class="content body">
                <!-- Main content -->
                <div class="row">
                    <!-- left column -->

                    <div class="col-md-8">
                        <!-- general form elements disabled -->
                        <div class="box box-warning">

                            <div class="box-header">
                                <i class="fa fa-comments-o"></i>

                                <h3 class="box-title">Timeline</h3>
                            </div>
                            <div class="box-body chat" id="chat-box">
                                <? foreach ($posts as $post) : ?>
                                    <!-- chat item -->
                                    <div class="item">
                                        <?= Html::loadIMG('user4-128x128.jpg', [
                                            'alt' => 'user image',
                                            'class' => 'online'
                                        ])
                                        ?>

                                        <p class="message">
                                            <a href="#" class="name">
                                                <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 2:15
                                                </small>
                                                Mike Doe
                                            </a>
                                            <?= $post['post']; ?>
                                        </p>
                                        <div class="attachment">
                                            <h4>Attachments:</h4>

                                            <p class="filename">
                                                Theme-thumbnail-image.jpg
                                            </p>

                                            <div class="pull-right">
                                                <button class="btn btn-primary btn-sm btn-flat">Open</button>
                                            </div>
                                        </div>
                                        <!-- /.attachment -->
                                    </div>
                                    <!-- /.item -->
                                <? endforeach; ?>
                                <!-- chat item -->
                                <div class="item">
                                    <?= Html::loadIMG('user4-128x128.jpg', ['alt' => 'user image', 'class' => 'online']) ?>

                                    <p class="message">
                                        <a href="#" class="name">
                                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 2:15
                                            </small>
                                            Mike Doe
                                        </a>
                                        I would like to meet you to discuss the latest news about
                                        the arrival of the new theme. They say it is going to be one the
                                        best themes on the market
                                    </p>
                                    <div class="attachment">
                                        <h4>Attachments:</h4>

                                        <p class="filename">
                                            Theme-thumbnail-image.jpg
                                        </p>

                                        <div class="pull-right">
                                            <button class="btn btn-primary btn-sm btn-flat">Open</button>
                                        </div>
                                    </div>
                                    <!-- /.attachment -->
                                </div>
                                <!-- /.item -->
                                <!-- chat item -->
                                <div class="item">
                                    <?= Html::loadIMG('user3-128x128.jpg', ['alt' => 'user image', 'class' => 'offline']) ?>

                                    <p class="message">
                                        <a href="#" class="name">
                                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15
                                            </small>
                                            Alexander Pierce
                                        </a>
                                        I would like to meet you to discuss the latest news about
                                        the arrival of the new theme. They say it is going to be one the
                                        best themes on the market
                                    </p>
                                </div>
                                <!-- /.item -->
                                <!-- chat item -->
                                <div class="item">
                                    <?= Html::loadIMG('user2-160x160.jpg', ['alt' => 'user image', 'class' => 'offline']) ?>

                                    <p class="message">
                                        <a href="#" class="name">
                                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:30
                                            </small>
                                            Susan Doe
                                        </a>
                                        I would like to meet you to discuss the latest news about
                                        the arrival of the new theme. They say it is going to be one the
                                        best themes on the market
                                    </p>
                                </div>
                                <!-- /.item -->
                            </div>
                            <!-- /.chat -->
                            <div class="box-footer">
                                <div class="input-group">

                                </div>
                            </div>
                        </div>
                        <!-- /.box -->
                    </div>
                    <!--/.col (right) -->

                    <div class="col-md-4">
                        <!-- Form Element sizes -->
                        <? if (Ngaji\Http\Request::is_authenticated()) : ?>
                            <div class="box box-success">
                                <?= Html::form_begin('index.php/post/add') ?>
                                <div class="box-header">
                                    <!-- <h3 class="box-title">@ -->
                                    <? //= Ngaji\Http\Request::get_user('username') ?>
                                    <!-- </h3> -->

                                    <h3 class="box-title">@<?= Ngaji\Http\Request::user()->username ?></h3>
                                </div>
                                <div class="box-body">
                                    <div class="form-group">
                                        <label>Post your tweet!</label>
                                        <textarea
                                            class="form-control" rows="3" placeholder="Write something ..."
                                            name="post"></textarea>
                                        <br/>

                                    </div>
                                    <div class="pull-right">
                                        <button class="btn btn-primary btn-sm btn-flat">Tweet</button>
                                    </div>
                                </div>
                                <?= Html::form_end() ?>
                                <!-- /.box-body -->
                                <div class="box-footer">
                                </div>
                            </div>
                            <!-- /.box -->
                        <? else : ?>
                            <!-- Input addon -->
                            <div class="box box-success">
                                <div class="box-header">
                                    <h3 class="box-title">
                                        <b>Ini</b>FORUM
                                    </h3>
                                </div>
                                <div class="box-body">
                                    <p class="login-box-msg">Sign in to start your session</p>
                                        <?= Html::form_begin('login') ?>
                                        <div class="form-group has-feedback">
                                            <input id="id_username" name="username" type="text" class="form-control"
                                                   placeholder="Username"
                                                   required="true"/>
                                            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                                        </div>
                                        <div class="form-group has-feedback">
                                            <input id="id_password" name="password" type="password" class="form-control"
                                                   placeholder="Password" required="true"/>
                                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-8"></div>
                                            <!-- /.col -->
                                            <div class="col-xs-4">
                                                <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In
                                                </button>
                                            </div>
                                            <!-- /.col -->
                                        </div>
                                    <?= Html::form_end() ?>
                                </div>
                            </div>
                        <? endif; ?>
                    </div>
                    <!-- /Form Element sizes -->

                    <!-- category element -->
                    <div class="col-md-4">
                        <!-- PRODUCT LIST -->
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Forum Category</h3>

                                <div class="box-tools pull-right">
                                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                    </button>
                                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <? foreach ($categories as $category) : ?>
                                    <ul class="products-list product-list-in-box">
                                        <li class="item">
                                            <div class="product-img">
                                                <img src="http://placehold.it/50x50/d2d6de/ffffff" alt="Product Image"/>
                                            </div>
                                            <div class="product-info">
                                                <a href="#" class="product-title"><?= $category['name'] ?>
                                                    <span class="label label-warning pull-right">$1800</span>
                                                </a>
                                                <span class="product-description">
                                                  Samsung 32" 1080p 60Hz LED Smart HDTV.
                                                </span>
                                            </div>
                                        </li>
                                        <!-- /.item -->
                                    </ul>
                                <? endforeach; ?>
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer text-center">
                                <a href="#" class="uppercase">View All Categories</a>
                            </div>
                            <!-- /.box-footer -->
                        </div>
                        <!-- /.box -->
                        <!-- /category element -->
                    </div>
                    <div class='col-md-4'>
                        <!-- USERS LIST -->
                        <div class="box box-danger">
                            <div class="box-header with-border">
                                <h3 class="box-title">Latest Members</h3>

                                <div class="box-tools pull-right">
                                    <span class="label label-danger">8 New Members</span>
                                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                    </button>
                                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body no-padding">
                                <ul class="users-list clearfix">
                                    <li>
                                        <?= Html::loadIMG('user1-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Alexander Pierce</a>
                                        <span class="users-list-date">Today</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user8-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Norman</a>
                                        <span class="users-list-date">Yesterday</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user7-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Jane</a>
                                        <span class="users-list-date">12 Jan</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user6-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">John</a>
                                        <span class="users-list-date">12 Jan</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user2-160x160.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Alexander</a>
                                        <span class="users-list-date">13 Jan</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user5-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Sarah</a>
                                        <span class="users-list-date">14 Jan</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user4-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Nora</a>
                                        <span class="users-list-date">15 Jan</span>
                                    </li>
                                    <li>
                                        <?= Html::loadIMG('user3-128x128.jpg', ['alt' => 'user image']) ?>
                                        <a class="users-list-name" href="#">Nadia</a>
                                        <span class="users-list-date">15 Jan</span>
                                    </li>
                                </ul>
                                <!-- /.users-list -->
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer text-center">
                                <a href="#" class="uppercase">View All Users</a>
                            </div>
                            <!-- /.box-footer -->
                        </div>
                        <!--/.box -->

                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.content -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.content-wrapper -->
        <footer class="main-footer">
            <div class="container-fluid">
                <div class="pull-right hidden-xs">
                    <a>Made By <i>Ngaji 2.0, AngularJS</i> and <i class="fa fa-heart"></i></a>
                </div>
                <strong>Copyright &copy;<a>OckiFals</a>.</strong> All
                rights reserved.
            </div>
            <!-- /.container -->
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <?= Html::load('js', 'plugins/jQuery/jQuery-2.1.3.min.js') ?>
    <!-- Bootstrap 3.3.2 JS -->
    <?= Html::load('js', 'bootstrap.min.js') ?>
    <!-- SlimScroll -->
    <?= Html::load('js', 'plugins/slimScroll/jquery.slimscroll.min.js') ?>
    <!-- FastClick -->
    <?= Html::load('js', 'plugins/fastclick/fastclick.min.js') ?>
    <!-- AdminLTE App -->
    <?= Html::load('js', 'dist/app.min.js') ?>
</body>
</html>