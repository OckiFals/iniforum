<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<!-- Bootstrap 3.3.2 -->
<?= Html::load('css', 'bootstrap.min.css') ?>
<?= Html::load('css', 'font-awesome.min.css') ?>
<link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css"/>
<!-- Theme style -->
<?= Html::load('css', 'dist/AdminLTE.min.css') ?>
<!-- AdminLTE Skins. Choose a skin from the css/skins
    folder instead of downloading all of them to reduce the load. -->
<?= Html::load('css', 'dist/skins/skin-blue.min.css') ?>